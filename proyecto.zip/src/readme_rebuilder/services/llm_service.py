from __future__ import annotations

import json
from typing import Type, TypeVar
from urllib import error, request

from pydantic import BaseModel

from readme_rebuilder.config import LLMSettings

T = TypeVar('T', bound=BaseModel)


class LLMService:
    def __init__(self, settings: LLMSettings) -> None:
        self.settings = settings
        self.observer = None
        self.requested_model = settings.model
        self.resolved_model = settings.model
        self.model = None

    # ── Construcción del modelo según backend ─────────────────────────────────

    def _build_model_ollama(self, model_name: str):
        try:
            from langchain_ollama import ChatOllama
        except ModuleNotFoundError as exc:
            raise RuntimeError(
                'Falta langchain-ollama. Instálala con: pip install langchain-ollama'
            ) from exc
        return ChatOllama(
            model=model_name,
            base_url=self.settings.base_url,
            temperature=self.settings.temperature,
        )

    def _build_model_llamacpp_server(self):
        """
        Usa llama.cpp en modo servidor (llama-server o llama-cpp-python server).
        El servidor expone una API compatible con OpenAI en llamacpp_base_url.
        Arrancar el servidor:
          llama-server -m modelo.gguf --port 8080 --host 0.0.0.0
        """
        try:
            from langchain_openai import ChatOpenAI
        except ModuleNotFoundError as exc:
            raise RuntimeError(
                'Falta langchain-openai. Instálala con: pip install langchain-openai'
            ) from exc
        base = self.settings.llamacpp_base_url.rstrip('/')
        return ChatOpenAI(
            base_url=f"{base}/v1",
            api_key="no-key",           # llama-server no requiere key real
            model="local-model",        # el servidor ignora este campo
            temperature=self.settings.temperature,
            max_retries=2,
        )

    def _build_model_llamacpp_local(self):
        """
        Usa llama-cpp-python directamente (sin servidor).
        Requiere: pip install llama-cpp-python
        El modelo se carga en memoria en este proceso.
        """
        try:
            from langchain_community.llms import LlamaCpp
            from langchain_core.callbacks import CallbackManager, StreamingStdOutCallbackHandler
        except ModuleNotFoundError as exc:
            raise RuntimeError(
                'Falta llama-cpp-python. Instálala con: pip install llama-cpp-python'
            ) from exc

        n_threads = self.settings.llamacpp_n_threads or None  # None = auto
        return LlamaCpp(
            model_path=self.settings.llamacpp_model_path,
            temperature=self.settings.temperature,
            n_ctx=self.settings.llamacpp_n_ctx,
            n_threads=n_threads,
            n_gpu_layers=self.settings.llamacpp_n_gpu_layers,
            verbose=False,
        )

    def _build_model(self, model_name: str):
        backend = self.settings.backend
        if backend == "ollama":
            return self._build_model_ollama(model_name)
        if backend == "llamacpp":
            if self.settings.llamacpp_model_path:
                return self._build_model_llamacpp_local()
            return self._build_model_llamacpp_server()
        raise ValueError(f"Backend desconocido: '{backend}'. Usa 'ollama' o 'llamacpp'.")

    def _ensure_model(self) -> None:
        if self.model is None:
            self.model = self._build_model(self.resolved_model)

    # ── Observer ──────────────────────────────────────────────────────────────

    def set_observer(self, observer) -> None:
        self.observer = observer

    def clear_observer(self) -> None:
        self.observer = None

    # ── Helpers Ollama ────────────────────────────────────────────────────────

    def _normalize_model_name(self, value: str) -> str:
        return value.removesuffix(':latest')

    def _fallback_candidates(self, requested: str) -> list[str]:
        requested_norm = self._normalize_model_name(requested)
        candidates: list[str] = []
        if '-coder:' in requested:
            candidates.append(requested.replace('-coder:', ':'))
        if requested.endswith('-coder'):
            candidates.append(requested[:-6])
        candidates.extend([
            'qwen2.5:7b', 'qwen2.5-coder:7b', 'qwen2.5:3b',
            'llama3.1:8b', 'mistral:7b', 'phi4:14b',
        ])
        dedup: list[str] = []
        seen: set[str] = {requested, requested_norm}
        for candidate in candidates:
            norm = self._normalize_model_name(candidate)
            if candidate in seen or norm in seen:
                continue
            dedup.append(candidate)
            seen.add(candidate)
            seen.add(norm)
        return dedup

    def _fetch_installed_models_ollama(self) -> list[str]:
        base = self.settings.base_url.rstrip('/')
        req = request.Request(f'{base}/api/tags', method='GET')
        try:
            with request.urlopen(req, timeout=5) as response:
                payload = json.loads(response.read().decode('utf-8'))
        except error.URLError as exc:
            raise RuntimeError(
                f'No fue posible contactar Ollama en {self.settings.base_url}. '
                'Verifica que el servicio esté arriba y escuchando en ese puerto.'
            ) from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError('Ollama respondió con un JSON inválido al consultar /api/tags.') from exc
        models = payload.get('models', [])
        names = [item.get('name', '').strip() for item in models if item.get('name')]
        return sorted(set(names))

    def _fetch_installed_models_llamacpp(self) -> list[str]:
        """Comprueba que el servidor llama.cpp responde."""
        if self.settings.llamacpp_model_path:
            # Modo local: el modelo existe si el archivo existe
            from pathlib import Path
            p = Path(self.settings.llamacpp_model_path)
            if not p.exists():
                raise RuntimeError(
                    f"Modelo GGUF no encontrado: {self.settings.llamacpp_model_path}"
                )
            return [p.name]

        # Modo servidor: ping al endpoint de modelos (compatible OpenAI)
        base = self.settings.llamacpp_base_url.rstrip('/')
        req = request.Request(f'{base}/v1/models', method='GET')
        try:
            with request.urlopen(req, timeout=5) as response:
                payload = json.loads(response.read().decode('utf-8'))
        except error.URLError as exc:
            raise RuntimeError(
                f'No fue posible contactar llama.cpp en {self.settings.llamacpp_base_url}. '
                'Asegúrate de que el servidor está corriendo:\n'
                '  llama-server -m modelo.gguf --port 8080 --host 0.0.0.0'
            ) from exc
        except json.JSONDecodeError:
            return ['local-model']
        data = payload.get('data', [])
        names = [item.get('id', 'local-model') for item in data]
        return names or ['local-model']

    # ── Preflight ─────────────────────────────────────────────────────────────

    def preflight(self) -> dict:
        backend = self.settings.backend

        if backend == "llamacpp":
            installed = self._fetch_installed_models_llamacpp()
            resolved = installed[0] if installed else 'local-model'
            self.resolved_model = resolved
            self.model = self._build_model(resolved)
            source = (
                f"llama.cpp local · {self.settings.llamacpp_model_path}"
                if self.settings.llamacpp_model_path
                else f"llama.cpp server · {self.settings.llamacpp_base_url}"
            )
            return {
                'base_url':        self.settings.llamacpp_base_url,
                'requested_model': self.settings.llamacpp_model_path or 'server',
                'resolved_model':  resolved,
                'used_fallback':   False,
                'installed_models': installed,
                'backend':         'llamacpp',
                'source':          source,
            }

        # ── Ollama ────────────────────────────────────────────────────────────
        installed = self._fetch_installed_models_ollama()
        installed_norm = {self._normalize_model_name(name): name for name in installed}
        requested = self.requested_model
        requested_norm = self._normalize_model_name(requested)

        if requested in installed:
            resolved = requested
            used_fallback = False
        elif requested_norm in installed_norm:
            resolved = installed_norm[requested_norm]
            used_fallback = resolved != requested
        else:
            resolved = ''
            used_fallback = False
            for candidate in self._fallback_candidates(requested):
                candidate_norm = self._normalize_model_name(candidate)
                if candidate in installed:
                    resolved = candidate
                    used_fallback = True
                    break
                if candidate_norm in installed_norm:
                    resolved = installed_norm[candidate_norm]
                    used_fallback = True
                    break

        if not resolved:
            available = ', '.join(installed[:8]) if installed else 'sin modelos instalados'
            raise RuntimeError(
                f"El modelo configurado '{requested}' no está instalado en Ollama. "
                f"Modelos detectados: {available}. "
                'Puedes corregirlo con --model, OLLAMA_MODEL o editando config.yaml.'
            )

        if resolved != self.resolved_model or self.model is None:
            self.resolved_model = resolved
            self.model = self._build_model(resolved)

        return {
            'base_url':        self.settings.base_url,
            'requested_model': requested,
            'resolved_model':  self.resolved_model,
            'used_fallback':   used_fallback,
            'installed_models': installed,
            'backend':         'ollama',
        }

    # ── Summarize ─────────────────────────────────────────────────────────────

    def _summarize_model_output(self, value: BaseModel | str) -> tuple[str, str | None]:
        if isinstance(value, BaseModel):
            data = value.model_dump()
            compact = json.dumps(data, ensure_ascii=False, indent=2)
            if 'path' in data and 'purpose' in data:
                return f"{data['path']} · {data['purpose'][:120]}", compact[:1400]
            if 'project_name' in data and 'one_liner' in data:
                return f"{data['project_name']} · {data['one_liner'][:120]}", compact[:1600]
            if 'summary' in data and 'missing_sections' in data:
                missing = ', '.join(data.get('missing_sections', [])[:3]) or 'sin vacíos críticos'
                return f'README previo evaluado · faltantes: {missing}', compact[:1400]
            if 'title' in data and 'tagline' in data:
                return f"Secciones listas · {data['title'][:80]}", compact[:1600]
            return 'Salida estructurada generada', compact[:1600]

        text = str(value).strip()
        first_line = text.splitlines()[0][:140] if text else 'sin contenido'
        return first_line, text[:1400] if text else None

    # ── LlamaCpp structured output (sin with_structured_output nativo) ────────

    def _structured_llamacpp(self, prompt: str, schema: Type[T]) -> T:
        """
        llama-cpp-python no soporta with_structured_output de LangChain.
        Usamos grammar-based JSON o simplemente pedimos JSON en el prompt
        y parseamos la respuesta.
        """
        schema_json = json.dumps(schema.model_json_schema(), ensure_ascii=False, indent=2)
        full_prompt = (
            f"{prompt}\n\n"
            f"Respond ONLY with a valid JSON object matching this schema exactly. "
            f"No explanation, no markdown, no code fences.\n\n"
            f"Schema:\n{schema_json}"
        )
        response = self.model.invoke(full_prompt)
        content = getattr(response, 'content', response)
        if isinstance(content, list):
            content = json.dumps(content, ensure_ascii=False)
        text = str(content).strip()

        # Limpiar posibles code fences que el modelo añada igualmente
        if text.startswith('```'):
            lines = text.splitlines()
            text = '\n'.join(
                line for line in lines
                if not line.strip().startswith('```')
            ).strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Intento de extracción: buscar el primer { ... } del texto
            import re
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                data = json.loads(match.group())
            else:
                raise RuntimeError(
                    f"llama.cpp no devolvió JSON válido.\nRespuesta recibida:\n{text[:500]}"
                )
        return schema.model_validate(data)

    # ── API pública ───────────────────────────────────────────────────────────

    def structured(self, prompt: str, schema: Type[T], label: str = 'structured_call') -> T:
        self._ensure_model()
        if self.observer:
            self.observer.llm_prompt(label=label, prompt=prompt)
            self.observer.llm_start(label=label, prompt_chars=len(prompt), schema_name=schema.__name__)

        if self.settings.backend == 'llamacpp':
            result = self._structured_llamacpp(prompt, schema)
        else:
            chain = self.model.with_structured_output(schema)
            result = chain.invoke(prompt)

        if self.observer:
            summary, excerpt = self._summarize_model_output(result)
            self.observer.llm_result(label=label, summary=summary, raw_excerpt=excerpt)
        return result

    def text(self, prompt: str, label: str = 'text_call') -> str:
        self._ensure_model()
        if self.observer:
            self.observer.llm_prompt(label=label, prompt=prompt)
            self.observer.llm_start(label=label, prompt_chars=len(prompt), schema_name=None)
        response = self.model.invoke(prompt)
        content = getattr(response, 'content', response)
        if isinstance(content, list):
            rendered = json.dumps(content, ensure_ascii=False, indent=2)
        else:
            rendered = str(content)
        if self.observer:
            summary, excerpt = self._summarize_model_output(rendered)
            self.observer.llm_result(label=label, summary=summary, raw_excerpt=excerpt)
        return rendered
